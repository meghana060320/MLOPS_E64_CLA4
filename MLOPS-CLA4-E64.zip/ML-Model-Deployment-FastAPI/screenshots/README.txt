Save real screenshots here after running the project:
1. online_inference.png
2. batch_inference.png
3. streaming_inference.png
4. fastapi_health.png
5. fastapi_predict_valid.png
6. fastapi_predict_invalid.png
These are intentionally not fabricated; capture them from your actual execution.
